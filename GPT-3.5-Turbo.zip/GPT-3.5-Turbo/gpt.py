import tkinter as tk
import threading
from queue import Queue
import time
import openai

# Set up OpenAI API key
api_key = "PASTE YOUR API KEY HERE"
openai.api_key = api_key


# Initialize the conversation history with a message from the chatbot
message_log = [
    {"role": "system", "content": "You are so good."}
]

# Create a queue to communicate between the GUI and the background thread
queue = Queue()

# Function to send a message to the OpenAI chatbot model and return its response
def send_message(message_log):
    # Use OpenAI's ChatCompletion API to get the chatbot's response
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # The name of the OpenAI chatbot model to use
        messages=message_log,   # The conversation history up to this point, as a list of dictionaries
        max_tokens=3800,        # The maximum number of tokens (words or subwords) in the generated response
        stop=None,              # The stopping sequence for the generated response, if any (not used here)
        temperature=0.7,        # The "creativity" of the generated response (higher temperature = more creative)
    )

    # Find the first response from the chatbot that has text in it (some responses may not have text)
    for choice in response.choices:
        if "text" in choice:
            return choice.text

    # If no response with text is found, return the first response's content (which may be empty)
    return response.choices[0].message.content

# Function to handle incoming messages from the background thread
def handle_messages():
    # Show the greeting message in the chat log
    chat_log.config(state=tk.NORMAL)
    chat_log.insert(tk.END, "ChatBot: Hello! I will be your assistant for today. How can I help you?\n\n")
    chat_log.yview_moveto(1.0)  # Scroll to the bottom

    while True:
        message = queue.get()
        if message == "quit":
            # End the loop and quit the program
            break
        elif message["role"] == "assistant":
            # Add the chatbot's response to the conversation history and print it to the console
            message_log.append(message)
            chat_log.insert(tk.END, "ChatBot: " + message["content"] + "\n")
        else:
            # Add the user's message to the conversation history and print it to the console
            message_log.append(message)
            chat_log.insert(tk.END, "You: " + message["content"] + "\n")

        chat_log.yview_moveto(1.0)  # Scroll to the bottom

# Function to handle user input from the GUI
def handle_input(event):
    # Disable the input field to prevent the user from typing while the AI assistant is processing their message
    input_field.config(state=tk.DISABLED)

    # Get the user's input from the input field
    user_input = input_field.get("1.0", tk.END)
    input_field.delete("1.0", tk.END)

    # If the user types "quit", end the loop and print a goodbye message
    if user_input.lower() == "quit":
        queue.put("quit")
        window.quit()
    else:
        # Add the user's message to the conversation history and print it to the console
        message_log.append({"role": "user", "content": user_input})
        chat_log.config(state=tk.NORMAL)
        chat_log.insert(tk.END, "You: ")

        # Typing animation
        for i in range(len(user_input)):
            chat_log.insert(tk.END, user_input[i])
            chat_log.update()
            time.sleep(0.05)

        chat_log.insert(tk.END, "\n")

        # Disable the chat log again before printing the chatbot's response
        chat_log.config(state=tk.DISABLED)

        # Send the conversation history to the chatbot and get its response
        response = send_message(message_log)

        # Add the chatbot's response to the conversation history and print it to the console
        message_log.append({"role": "assistant", "content": response})
        chat_log.config(state=tk.NORMAL)
        chat_log.insert(tk.END, "Chatbot: ")

        # Typing animation
        for i in range(len(response)):
            chat_log.insert(tk.END, response[i])
            chat_log.update()
            time.sleep(0.05)

        chat_log.insert(tk.END, "\n")

    # Re-enable the input field so that the user can continue typing
    input_field.config(state=tk.NORMAL)

# Create the GUI
window = tk.Tk()
window.title("LunaGPT")

# Set the window icon
window.iconbitmap("Girl.ico")

# Get the screen dimensions
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()

# Set the window dimensions and position to be centered
window_width = 1200
window_height = 850
window_x = (screen_width // 2) - (window_width // 2)
window_y = (screen_height // 2) - (window_height // 2)
window.geometry(f"{window_width}x{window_height}+{window_x}+{window_y}")
window.tk_setPalette(background='#4A4A4A')

# Create the chat log
chat_log = tk.Text(window, height=33, width=120, wrap=tk.WORD)
chat_log.config(font=("Arial", 15))
chat_log.config(takefocus=False)  # Prevent focus on the widget
chat_log.config(cursor='arrow')  # Change cursor to arrow
chat_log.config(bg="#1C1C1C", fg="white")

# Create a scrollbar and link it to the chat log
scrollbar = tk.Scrollbar(window, command=chat_log.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
chat_log.config(yscrollcommand=scrollbar.set)

chat_log.pack(side=tk.TOP, padx=5, pady=5)

# Function to clear the conversation history
def clear_history():
    global message_log
    message_log = []
    chat_log.config(state=tk.NORMAL)
    chat_log.delete("1.0", tk.END)

# Create the clear button
clear_button = tk.Button(window, text="Clear", font=("Helvetica", 12), command=clear_history, width=10, height=2)
clear_button.pack(side=tk.RIGHT, padx=(0, 30), pady=(2, 0))

# Create the input field and bind the handle_input function to the "Return" key
input_field = tk.Text(window, height=25, width=90, font=("Arial", 14))
input_field.config(bg="#6D6D6D")
input_field.pack(side=tk.BOTTOM, padx=3, pady=4)

# Create a scrollbar widget and attach it to the input field
scrollbar = tk.Scrollbar(window, command=input_field.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
input_field.config(yscrollcommand=scrollbar.set)

input_field.bind("<Return>", handle_input)
input_field.focus()

# Create the background thread and start it
message_thread = threading.Thread(target=handle_messages)
message_thread.start()

# Start the main event loop
window.mainloop()

# When the main event loop ends, send the "quit" message to the background thread to end it
queue.put("quit")
message_thread.join()